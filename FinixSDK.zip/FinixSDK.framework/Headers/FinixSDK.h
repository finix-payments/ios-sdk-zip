//
//  ios_sdk.h
//  ios-sdk
//
//  Created by Matt Sommer on 4/3/18.
//  Copyright © 2018 Finix Payments, Inc. All rights reserved.
//

//#import <UIKit/UIKit.h>

//! Project version number for ios_sdk.
//FOUNDATION_EXPORT double ios_sdkVersionNumber;

//! Project version string for ios_sdk.
//FOUNDATION_EXPORT const unsigned char ios_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ios_sdk/PublicHeader.h>


